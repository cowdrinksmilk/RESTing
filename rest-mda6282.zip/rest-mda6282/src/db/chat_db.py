from .swen344_db_utils import *

def get_all_users():
    """get all users from the database."""
    # pull users w the filemds asked
    users = exec_get_all('SELECT id, username, email, created_at, suspended_until FROM users ORDER BY id')
    # tuple -> dict
    result = []
    for user in users:
        # matches col to key
        result.append({
            'id': user[0],
                'username': user[1],
            'email': user[2] if len(user) > 2 else None,
                'created_at': str(user[3]) if user[3] else None,
            'suspended_until': str(user[4]) if user[4] else None
        })
    return result

def get_communities_and_channels():
    """get all communities and their channels."""
    # left join has communities without channels
    data = exec_get_all('''
            SELECT c.id, c.name, c.description,
        ch.id, ch.name, ch.description
            FROM communities c
        LEFT JOIN channels ch ON c.id = ch.community_id
            ORDER BY c.id, ch.id
    ''')
    # organize by comm
    communities = {}
    for row in data:
        community_id = row[0]
        if community_id not in communities:
            communities[community_id] = {
                    'id': community_id,
                'name': row[1],
                    'description': row[2],
                'channels': []
            }
        # add channel if it ecxits
        if row[3]: 
            communities[community_id]['channels'].append({
                    'id': row[3],
                'name': row[4],
                    'description': row[5]
            })
    # convert dict to list for json response
    return list(communities.values())

def search_messages(content=None, from_date=None, to_date=None):
    """search messages by content and dates."""
    # 
    sql = '''
            SELECT m.id, m.channel_id, m.content, m.sent_at, u.username, ch.name as channel_name
        FROM messages m
            JOIN users u ON m.user_id = u.id
        JOIN channels ch ON m.channel_id = ch.id
            WHERE 1=1
    '''
    params = {}
    # filters
    if content:
        sql += ' AND m.content LIKE %(content)s'
        params['content'] = f'%{content}%'
    if from_date:
        sql += ' AND m.sent_at >= %(from_date)s'
        params['from_date'] = from_date
    if to_date:
        sql += ' AND m.sent_at <= %(to_date)s'
        params['to_date'] = to_date
    # recent first
    sql += ' ORDER BY m.sent_at DESC'
    messages = exec_get_all(sql, params)
    # results become dicts
    result = []
    for msg in messages:
        # matches result to dictionary keys
        result.append({
                'id': msg[0],
            'channel_id': msg[1],
                'content': msg[2],
            'sent_at': str(msg[3]),
                'username': msg[4],
            'channel_name': msg[5]
        })
    # return msg list
    return result

def get_channel_messages(channel_id):
    """get all messages in a specific channel."""
    # query messages for the given channel
    messages = exec_get_all('''
            SELECT m.id, m.channel_id, m.content, m.sent_at, u.username, m.is_read
        FROM messages m
            JOIN users u ON m.user_id = u.id
        WHERE m.channel_id = %(channel_id)s
            ORDER BY m.sent_at
    ''', {'channel_id': channel_id})
    # dictionary
    result = []
    for msg in messages:
        # matches each col to key
        result.append({
            'id': msg[0],
                'channel_id': msg[1],
            'content': msg[2],
            'sent_at': str(msg[3]),
            'username': msg[4],
            'is_read': msg[5] if len(msg) > 5 else False
        })
    # return the list msgdictionaries
    return result

# -- rest 2

# Add to chat_db.py

# User operations
def get_user_by_id(user_id):
    """Get a specific user by ID."""
    user = exec_get_one('SELECT id, username, email, created_at, suspended_until FROM users WHERE id = %(user_id)s', 
                       {'user_id': user_id})
    if not user:
        return None
    
    return {
        'id': user[0],
        'username': user[1],
        'email': user[2],
        'created_at': str(user[3]) if user[3] else None,
        'suspended_until': str(user[4]) if user[4] else None
    }

def create_user(user_data):
    """Create a new user."""
    # Check if username already exists
    exists = exec_get_one('SELECT id FROM users WHERE username = %(username)s',
                        {'username': user_data['username']})
    if exists:
        return {'error': 'Username already exists'}, 400
    
    # Insert the new user
    user_id = exec_get_one('''
        INSERT INTO users (username, email)
        VALUES (%(username)s, %(email)s)
        RETURNING id
    ''', user_data)
    
    # If password was provided, create auth entry
    if 'password' in user_data and user_data['password']:
        # In a real app, you would hash the password here
        exec_commit('''
            INSERT INTO user_auth (user_id, password_hash)
            VALUES (%(user_id)s, %(password_hash)s)
        ''', {'user_id': user_id[0], 'password_hash': user_data['password']})
    
    return get_user_by_id(user_id[0])

def update_user(user_id, user_data):
    """Update a user's information."""
    # Build update SQL dynamically based on provided fields
    update_parts = []
    params = {'user_id': user_id}
    
    if 'username' in user_data and user_data['username']:
        update_parts.append('username = %(username)s')
        params['username'] = user_data['username']
        
    if 'email' in user_data and user_data['email']:
        update_parts.append('email = %(email)s')
        params['email'] = user_data['email']
    
    if not update_parts:
        return {'error': 'No update parameters provided'}, 400
    
    # Execute the update
    sql = f"UPDATE users SET {', '.join(update_parts)} WHERE id = %(user_id)s"
    exec_commit(sql, params)
    
    return get_user_by_id(user_id)

def delete_user(user_id):
    """Delete a user."""
    # Check if user exists
    user = get_user_by_id(user_id)
    if not user:
        return {'error': 'User not found'}, 404
    
    # Delete the user
    exec_commit('DELETE FROM users WHERE id = %(user_id)s', {'user_id': user_id})
    
    return {'message': f'User {user_id} deleted successfully'}

# Community operations
def get_community(community_id):
    """Get a specific community with its channels."""
    # Get community info
    community = exec_get_one('''
        SELECT id, name, description, created_at
        FROM communities
        WHERE id = %(community_id)s
    ''', {'community_id': community_id})
    
    if not community:
        return None
    
    # Get channels for this community
    channels = exec_get_all('''
        SELECT id, name, description, created_at
        FROM channels
        WHERE community_id = %(community_id)s
        ORDER BY id
    ''', {'community_id': community_id})
    
    # Format response
    result = {
        'id': community[0],
        'name': community[1],
        'description': community[2],
        'created_at': str(community[3]) if community[3] else None,
        'channels': []
    }
    
    for channel in channels:
        result['channels'].append({
            'id': channel[0],
            'name': channel[1],
            'description': channel[2],
            'created_at': str(channel[3]) if channel[3] else None
        })
    
    return result

# Add to chat_db.py

def get_user_by_id(user_id):
    """Get a specific user by ID."""
    user = exec_get_one('SELECT id, username, email, created_at, suspended_until FROM users WHERE id = %(user_id)s', 
                       {'user_id': user_id})
    if not user:
        return {"error": "User not found"}, 404
    
    return {
        'id': user[0],
        'username': user[1],
        'email': user[2],
        'created_at': str(user[3]) if user[3] else None,
        'suspended_until': str(user[4]) if user[4] else None
    }

def create_user(user_data):
    """Create a new user."""
    # Check if username already exists
    exists = exec_get_one('SELECT id FROM users WHERE username = %(username)s',
                        {'username': user_data['username']})
    if exists:
        return {'error': 'Username already exists'}, 400
    
    # Insert the new user
    user_id = exec_get_one('''
        INSERT INTO users (username, email)
        VALUES (%(username)s, %(email)s)
        RETURNING id
    ''', {
        'username': user_data['username'],
        'email': user_data['email']
    })
    
    if 'password' in user_data and user_data['password'] and 'user_auth' in exec_get_one("SELECT tablename FROM pg_tables WHERE schemaname='public'")[0]:
        # In a real app, you would hash the password here
        exec_commit('''
            INSERT INTO user_auth (user_id, password_hash)
            VALUES (%(user_id)s, %(password_hash)s)
        ''', {'user_id': user_id[0], 'password_hash': user_data['password']})
    
    return get_user_by_id(user_id[0])

def update_user(user_id, user_data):
    """Update a user's information."""
    # Check if user exists
    user_exists = exec_get_one('SELECT id FROM users WHERE id = %(user_id)s', {'user_id': user_id})
    if not user_exists:
        return {"error": "User not found"}, 404
        
    # Build update SQL dynamically based on provided fields
    update_parts = []
    params = {'user_id': user_id}
    
    if 'username' in user_data and user_data['username']:
        update_parts.append('username = %(username)s')
        params['username'] = user_data['username']
        
    if 'email' in user_data and user_data['email']:
        update_parts.append('email = %(email)s')
        params['email'] = user_data['email']
    
    if not update_parts:
        return {'error': 'No update parameters provided'}, 400
    
    # Execute the update
    sql = f"UPDATE users SET {', '.join(update_parts)} WHERE id = %(user_id)s"
    exec_commit(sql, params)
    
    return get_user_by_id(user_id)

def delete_user(user_id):
    """Delete a user."""
    # Check if user exists
    user_exists = exec_get_one('SELECT id FROM users WHERE id = %(user_id)s', {'user_id': user_id})
    if not user_exists:
        return {"error": "User not found"}, 404
    
    # Delete the user
    exec_commit('DELETE FROM users WHERE id = %(user_id)s', {'user_id': user_id})
    
    return {'message': f'User {user_id} deleted successfully'}