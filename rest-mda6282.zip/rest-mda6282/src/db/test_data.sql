-- rest setup
-- We specify our primary key here to be as repeatable as possible
INSERT INTO example_table(id, foo) VALUES
  (1, 'hello, world!');

-- Restart our primary key sequences here so inserting id=DEFAULT won't collide
ALTER SEQUENCE example_table_id_seq RESTART WITH 1000;

-- rest 1
-- inserting tests users
INSERT INTO users (username, email, suspended_until) VALUES
  ('user1', 'user1@example.com', NULL),
  ('user2', 'user2@example.com', NULL),
  ('user3', 'user3@example.com', '2030-01-01 00:00:00');

-- inserting tests communities
INSERT INTO communities (name, description) VALUES
  ('Community 1', 'This is the first community'),
  ('Community 2', 'This is the second community');

-- inserting channel;s
INSERT INTO channels (community_id, name, description) VALUES
  (1, 'general', 'General discussion for Community 1'),
  (1, 'random', 'Random chat for Community 1'),
  (2, 'general', 'General discussion for Community 2');

-- inserting texts
INSERT INTO messages (channel_id, user_id, content, sent_at, is_read) VALUES
  (1, 1, 'Hello world!', '2023-01-01 10:00:00', true),
  (1, 2, 'Whatcha up too!', '2023-01-01 10:05:00', false),
  (1, 3, 'bye bye birdie', '2023-01-01 10:10:00', false),
  (2, 1, 'Testung 1234', '2023-01-02 11:00:00', true),
  (2, 2, 'Womp house', '2023-01-02 11:30:00', false),
  (3, 1, 'Welcome to the Community', '2023-01-03 09:00:00', true),
  (3, 3, 'Thanks chat!', '2023-01-03 09:15:00', false);

-- restting sequences
ALTER SEQUENCE users_id_seq RESTART WITH 1000;
ALTER SEQUENCE communities_id_seq RESTART WITH 1000;
ALTER SEQUENCE channels_id_seq RESTART WITH 1000;
ALTER SEQUENCE messages_id_seq RESTART WITH 1000;

-- rest 2
-- authenticying a user
INSERT INTO user_auth (user_id, password_hash, last_login) VALUES
  (1, 'hashed_password_1', '2023-01-01 12:00:00'),
  (2, 'hashed_password_2', '2023-01-02 12:00:00'),
  (3, 'hashed_password_3', '2023-01-03 12:00:00');

-- adding memberships
INSERT INTO memberships (user_id, community_id, role) VALUES
  (1, 1, 'admin'),
  (1, 2, 'member'),
  (2, 1, 'member'),
  (2, 2, 'admin'),
  (3, 1, 'member');

-- reactio ns
INSERT INTO reactions (message_id, user_id, reaction_type) VALUES
  (1, 2, 'like'),
  (1, 3, 'laugh'),
  (2, 1, 'like'),
  (3, 2, 'heart'),
  (4, 3, 'like');

ALTER SEQUENCE user_auth_id_seq RESTART WITH 1000;
ALTER SEQUENCE memberships_id_seq RESTART WITH 1000;
ALTER SEQUENCE reactions_id_seq RESTART WITH 1000;