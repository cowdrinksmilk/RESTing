from flask_restful import Resource, reqparse
from db import chat_db

class MessageDetail(Resource):
    def get(self, message_id):
        # pull a message
        return chat_db.get_message(message_id)
        
    def put(self, message_id):
        # update message
        parser = reqparse.RequestParser()
        parser.add_argument('content', type=str, required=True)
        args = parser.parse_args()
        return chat_db.update_message(message_id, args)
        
    def delete(self, message_id):
        # delete a message
        return chat_db.delete_message(message_id)