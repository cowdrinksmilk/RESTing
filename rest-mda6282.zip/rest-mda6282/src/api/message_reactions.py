from flask_restful import Resource, reqparse
from db import chat_db

class MessageReactions(Resource):
    def get(self, message_id):
        # pull all of the reactions
        return chat_db.get_message_reactions(message_id)
        
    def post(self, message_id):
        # add a reaction
        parser = reqparse.RequestParser()
        parser.add_argument('user_id', type=int, required=True)
        parser.add_argument('reaction_type', type=str, required=True)
        args = parser.parse_args()
        
        return chat_db.add_reaction(message_id, args)
        
    def delete(self, message_id):
        # remove reaction
        parser = reqparse.RequestParser()
        parser.add_argument('user_id', type=int, required=True)
        parser.add_argument('reaction_type', type=str, required=True)
        args = parser.parse_args()
        return chat_db.remove_reaction(message_id, args)