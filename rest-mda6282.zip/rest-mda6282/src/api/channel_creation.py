from flask_restful import Resource, reqparse
from db import chat_db

class ChannelCreation(Resource):
    def post(self, community_id):
        # make a new channel within a community
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str, required=True)
        parser.add_argument('description', type=str)
        args = parser.parse_args()
        
        return chat_db.create_channel(community_id, args)