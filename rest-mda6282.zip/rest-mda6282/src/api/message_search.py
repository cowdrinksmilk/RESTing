from flask_restful import Resource, reqparse
from db import chat_db

class MessageSearch(Resource):
    def get(self):
        # search for messages including filters
        parser = reqparse.RequestParser()

        # search filter
        parser.add_argument('content', type=str, location='args')
        # data filter - from to
        parser.add_argument('from_date', type=str, location='args')
        parser.add_argument('to_date', type=str, location='args')
        # get the params
        args = parser.parse_args()
        
        try:
            # search using the params
            return chat_db.search_messages(
                content=args.get('content'),
                from_date=args.get('from_date'),
                to_date=args.get('to_date')
            )
        except Exception as e:
            # if error, log it
            print(f"Error in search_messages: {str(e)}")
            return {"error": str(e)}, 500
