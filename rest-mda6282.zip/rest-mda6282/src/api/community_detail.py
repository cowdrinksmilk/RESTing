from flask_restful import Resource, reqparse
from db import chat_db

class CommunityDetail(Resource):
    def get(self, community_id):
        # pull a community
        return chat_db.get_community(community_id)
        
    def put(self, community_id):
        # update a community
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str)
        parser.add_argument('description', type=str)
        args = parser.parse_args()
        
        return chat_db.update_community(community_id, args)
        
    def delete(self, community_id):
        # delete community
        return chat_db.delete_community(community_id)
