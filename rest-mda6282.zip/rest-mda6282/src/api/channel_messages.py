from flask_restful import Resource, reqparse
from db import chat_db

class ChannelMessages(Resource):
    def get(self, channel_id):
        """get messages in a channel."""
        try:
            # get messages for this channel
            return chat_db.get_channel_messages(channel_id)
        except Exception as e:
            # log error
            print(f"Error in get_channel_messages: {str(e)}")
            return {"error": str(e)}, 500
