from flask_restful import Resource, reqparse
from db import chat_db

class Users(Resource):
    def get(self):
        """get all users."""
        # get users from db
        users = chat_db.get_all_users()
        # send back as json
        return users