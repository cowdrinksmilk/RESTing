from flask_restful import Resource, reqparse
from db import chat_db

class ChannelDetail(Resource):
    def get(self, channel_id):
        # pull a specific channel
        return chat_db.get_channel(channel_id)
        
    def put(self, channel_id):
        # update channel
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str)
        parser.add_argument('description', type=str)
        args = parser.parse_args()
        return chat_db.update_channel(channel_id, args)
        
    def delete(self, channel_id): 
        # delete channel
        return chat_db.delete_channel(channel_id)

