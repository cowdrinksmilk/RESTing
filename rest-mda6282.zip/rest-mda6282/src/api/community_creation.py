from flask_restful import Resource, reqparse
from db import chat_db

class CommunityCreation(Resource):
    def post(self):
        # make a new community
        parser = reqparse.RequestParser()
        parser.add_argument('name', type=str, required=True)
        parser.add_argument('description', type=str)
        args = parser.parse_args()
        
        return chat_db.create_community(args)