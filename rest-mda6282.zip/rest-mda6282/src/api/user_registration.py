# src/api/user_registration.py
from flask_restful import Resource, reqparse
from db import chat_db
from flask import request

class UserRegistration(Resource):
    def post(self):
        # register a new user in the system: user, email, pass
        parser = reqparse.RequestParser()
        parser.add_argument('username', type=str, required=True)
        parser.add_argument('email', type=str, required=True)
        parser.add_argument('password', type=str, required=True)
        
        parser.add_argument('Content-Type', location='headers')
        args = parser.parse_args()
        # creates tje user
        return chat_db.create_user(args)