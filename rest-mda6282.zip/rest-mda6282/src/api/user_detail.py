from flask_restful import Resource, reqparse
from db import chat_db
from flask import request

class UserDetail(Resource):
    
    def get(self, user_id):
        # pull user id
        return chat_db.get_user_by_id(user_id)
        
    def put(self, user_id):
        # UDATES user info
        if not request.is_json:
            return {"error": "Request was not in JSON"}, 415 
        # pulls data
        data = request.get_json()
        
        return chat_db.update_user(user_id, data)
        
    def delete(self, user_id):
        # delete user
        return chat_db.delete_user(user_id)