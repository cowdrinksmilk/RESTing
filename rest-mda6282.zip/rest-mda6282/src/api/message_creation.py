from flask_restful import Resource, reqparse
from db import chat_db

class MessageCreation(Resource):
    def post(self, channel_id):
        # add a message in a channel
        parser = reqparse.RequestParser()
        parser.add_argument('user_id', type=int, required=True)
        parser.add_argument('content', type=str, required=True)
        args = parser.parse_args()
        
        return chat_db.create_message(channel_id, args)