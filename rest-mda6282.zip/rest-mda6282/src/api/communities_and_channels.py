from flask_restful import Resource, reqparse
from db import chat_db

class CommunitiesAndChannels(Resource):
    def get(self):
        # pull the data of all of the communities and channels
        return chat_db.get_communities_and_channels()
