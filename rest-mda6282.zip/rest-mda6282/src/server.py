from flask import Flask, jsonify
from flask_restful import Api
from api.management import *
from api.communities_and_channels import CommunitiesAndChannels
from api.message_search import MessageSearch
from api.channel_messages import ChannelMessages
from api.channel_detail import ChannelDetail
from api.channel_creation import ChannelCreation
from api.community_detail import CommunityDetail
from api.community_creation import CommunityCreation
from api.message_detail import MessageDetail
from api.message_creation import MessageCreation
from api.message_reactions import MessageReactions
from api.users import Users
from api.user_detail import UserDetail
from api.user_registration import UserRegistration
from db.example import rebuild_tables

app = Flask(__name__)
api = Api(app)

# Add a root endpoint to fix 404 errors
@app.route('/', methods=['GET'])
def index():
    return jsonify({"message": "Chat API server is running"})

# endpoints
api.add_resource(Init, '/manage/init')
api.add_resource(Version, '/manage/version')
# rest 1 - chatapi
api.add_resource(Users, '/users')
api.add_resource(CommunitiesAndChannels, '/communities')
api.add_resource(MessageSearch, '/messages/search')
api.add_resource(ChannelMessages, '/channels/<int:channel_id>/messages')
# rest 2 - crud ops
api.add_resource(UserDetail, '/users/<int:user_id>')
api.add_resource(UserRegistration, '/users/register')
api.add_resource(CommunityDetail, '/communities/<int:community_id>')
api.add_resource(CommunityCreation, '/communities/create')
api.add_resource(ChannelDetail, '/channels/<int:channel_id>')
api.add_resource(ChannelCreation, '/communities/<int:community_id>/channels')
api.add_resource(MessageDetail, '/messages/<int:message_id>')
api.add_resource(MessageCreation, '/channels/<int:channel_id>/messages/create')
api.add_resource(MessageReactions, '/messages/<int:message_id>/reactions')

if __name__ == '__main__':
    rebuild_tables()  
    app.run(debug=True, port=5001)