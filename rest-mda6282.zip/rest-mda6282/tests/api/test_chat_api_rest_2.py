import unittest
from tests.test_utils import *

class TestChatAPIREST2(unittest.TestCase):
    def setUp(self):
        # db reset
        print("\nReset database")
        post_rest_call(self, 'http://127.0.0.1:5001/manage/init')
    
    print ( "\n Test: Chat API REST 1 Completed. ")
    print ( "\n Testing: Chat API Rest 2. ")

    def test_get_user_by_id(self):
        print("\nTEST: Get User By ID")
        user_id = 1  # test data
        
        try:
            print("Getting user with ID", user_id)
            user = get_rest_call(self, f'http://127.0.0.1:5001/users/{user_id}')
            print("Pulled user: ", user)
            
            self.assertIsNotNone(user)
            self.assertEqual(user['id'], user_id)
            print("test passes: expected value is true.")
            # if test fails
        except Exception as e:
            print("tests failing: ", str(e))
            raise
    
    def test_create_user(self):
        # test to make a new user 
        print("\nTEST: Create User")
        new_user = {
            'username': 'bob',
            'email': 'bob@example.com',
            'password': 'password123'
        }
        
        try:
            # check if endpoint exists first
            try:
                response = requests.options('http://127.0.0.1:5001/users/register')
                if response.status_code == 404:
                    print("warning: /users/register endpoint not found. implement this first.")
                    self.skipTest("Endpoint not implemented")
            except requests.exceptions.ConnectionError:
                print("warning: couldn't connect to server. make sure it's running.")
                self.skipTest("Server not running")
            
            print("Creating new user with data:", new_user)
            user = post_rest_call(self, 'http://127.0.0.1:5001/users/register', new_user)
            print("Created user:", user)
            
            self.assertIsNotNone(user)
            self.assertEqual(user['username'], 'new_user')
            print("tests passing: created user has correct username")
            
            print("Verifying user exists in database")
            all_users = get_rest_call(self, 'http://127.0.0.1:5001/users')
            user_exists = any(u['username'] == 'new_user' for u in all_users)
            self.assertTrue(user_exists)
            print("tests passing: user exists in db")
        except Exception as e:
            print("tests failing: ", str(e))
            raise
    
    def test_update_user(self):
        print("\nTEST: Update User")
        user_id = 1  # assuming user 1 exists
        updates = {
            'username': 'bob1',
            'email': 'bob1@example.com'
        }
        try:
            print("Pulling user data for specified user ID", user_id)
            og_user = get_rest_call(self, f'http://127.0.0.1:5001/users/{user_id}')
            print("Original user data:", og_user)
            
            print("Updating user with new data: ", updates)
            updated_user = put_rest_call(self, f'http://127.0.0.1:5001/users/{user_id}', updates)
            print("Updated user data:", updated_user)
            
            self.assertEqual(updated_user['username'], 'bob1')
            self.assertEqual(updated_user['email'], 'bob1@example.com')
            print("tests passing: user data updated correctly")
            
            print("updating nonexistent user attempt ")
            non_existent_id = 9999
            try:
                # should fail with 404
                put_rest_call(self, f'http://127.0.0.1:5001/users/{non_existent_id}', updates, expected_code=404)
                print("tests passing: update of non-existent user failed as expected")
            except AssertionError as e:
                print("tests failing: ", str(e))
                
        except Exception as e:
            print("tests failing: ", str(e))
            raise
    
    def test_delete_user(self):
        # delete user test
        print("\nTEST: Delete User")
        user_id = 3  
        
        try:
            # check if user exists first
            print(f"checking is user: {user_id} exists.")
            try:
                user = get_rest_call(self, f'http://127.0.0.1:5001/users/{user_id}')
                print(f"User exists: {user}")
            except Exception as e:
                print(f"user {user_id} doesn't exist. using user 1 instead.")
                user_id = 1
            
            print(f"Deleting user:  {user_id}")
            result = delete_rest_call(self, f'http://127.0.0.1:5001/users/{user_id}')
            print("delettion result: ", result)
            
            print("chekcing is user is still in the database")
            try:
                get_rest_call(self, f'http://127.0.0.1:5001/users/{user_id}', expected_code=404)
                print("tests passing: user gone from db")
            except AssertionError:
                print("tests failing: user still exists after deletion")
                raise
            
            print("User nonexistent ")
            non_existent_id = 9999
            try:
                delete_rest_call(self, f'http://127.0.0.1:5001/users/{non_existent_id}', expected_code=404)
                print("tests passing: test failed as expected")
            except AssertionError as e:
                 # .
                print("tests failing: ", str(e))
            
        except Exception as e:
            print("tests failing: ", str(e))
    
    def test_list_messages(self):
        print("\nTEST: List of messages: ")
        
        try:
      
            try:
                response = requests.options('http://127.0.0.1:5001/channels/1/messages')
                if response.status_code == 404:
                    print("warning: messages endpoint not found. endpoint must be implemented forst.")
                    self.skipTest("no endpoint")

            except requests.exceptions.ConnectionError:
                print("warning: couldn't connect to server. make sure it's running.")
                self.skipTest("Server not running")
                
            print("Getting messages from channel 1")
            messages = get_rest_call(self, 'http://127.0.0.1:5001/channels/1/messages')
            print(f"Pulled {len(messages)} messages")
            
            if len(messages) > 0:
                print("Getting messages with limit=2")
                lim_msgs = get_rest_call(self, 'http://127.0.0.1:5001/channels/1/messages?limit=2')
                print(f"Pulled {len(lim_msgs)} messages with limit = 2")
                
                self.assertGreaterEqual(len(lim_msgs), 2)
                print("tests passing: messages are within limit")
            else:
                print("no messages found")
        except Exception as e:
            print("tests failing: ", str(e))
            raise
        print ( " Test: Chat API REST 2 Completed. ")