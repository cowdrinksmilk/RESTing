import unittest
from tests.test_utils import *

class TestChatAPIREST1(unittest.TestCase):
   
   def setUp(self):
       """set up test by resetting the db."""
       # init db before each test
       post_rest_call(self, 'http://127.0.0.1:5001/manage/init')
   
   def test_list_all_users(self):
       """test getting all users."""
       # get users from api
       users = get_rest_call(self, 'http://127.0.0.1:5001/users')
       
       # check ofwe get some users
       self.assertTrue(len(users) > 0)
       
       # check if user fields exist
       for user in users:
           self.assertIn('id', user)
           self.assertIn('username', user)
           self.assertIn('suspended_until', user)
   
   def test_list_communities_and_channels(self):
       """test getting communities and channels."""
       # get commu data
       communities = get_rest_call(self, 'http://127.0.0.1:5001/communities')
       
       # check ifwe have at least one
       self.assertTrue(len(communities) > 0)
       
       # check the data format
       for community in communities:
           self.assertIn('id', community)
           self.assertIn('name', community)
           self.assertIn('channels', community)
           self.assertTrue(isinstance(community['channels'], list))
   
   def test_search_messages_all(self):
       """test search with no filters."""
       # get all messages
       all_messages = get_rest_call(self, 'http://127.0.0.1:5001/messages/search')
       
       # check result is a list
       self.assertTrue(isinstance(all_messages, list))
       
       # check message fields
       if all_messages:
           for message in all_messages:
               self.assertIn('id', message)
               self.assertIn('content', message)
               self.assertIn('sent_at', message)
               self.assertIn('username', message)
               self.assertIn('channel_id', message)
   
   def test_search_messages_by_content(self):
       """test search by messagr content."""
       # get all messages 
       all_messages = get_rest_call(self, 'http://127.0.0.1:5001/messages/search')
       
       # use first message for search term
       if all_messages:
           # take first 5 chars as search term
           find_word = all_messages[0]['content'][:5]
           message_content = get_rest_call(self, f'http://127.0.0.1:5001/messages/search?content={find_word}')
           
           # check result format
           self.assertTrue(isinstance(message_content, list))
       else:
           # skip if no messages
           pass
   
   def test_search_messages_by_date_range(self):
       """test search by date range."""
       # use wide date range to find results
       find_data = get_rest_call(self, 'http://127.0.0.1:5001/messages/search?from_date=1900-01-01&to_date=2100-12-31')
       
       # check response type
       self.assertTrue(isinstance(find_data, list))
   
   def test_search_messages_combined_filters(self):
       """test search with text and dates."""
       # get all messages first
       all_messages = get_rest_call(self, 'http://127.0.0.1:5001/messages/search')
       
       # search with multiple filters
       if all_messages:
           find_word = all_messages[0]['content'][:5]
           mult_search = get_rest_call(self, f'http://127.0.0.1:5001/messages/search?content={find_word}&from_date=1900-01-01&to_date=2100-12-31')
           
           # check result format
           self.assertTrue(isinstance(mult_search, list))
       else:
           pass
   
   def test_specific_channel_messages(self):
       """test getting messages from a channel."""
       # find a real channel id
       communities = get_rest_call(self, 'http://127.0.0.1:5001/communities')
       
       if communities and communities[0]['channels']:
           # use first channel found
           channel_id = communities[0]['channels'][0]['id']
           messages = get_rest_call(self, f'http://127.0.0.1:5001/channels/{channel_id}/messages')
           
           # check result is a list
           self.assertTrue(isinstance(messages, list))
           
           # check message fields
           if messages:
               message = messages[0]
               self.assertIn('id', message)
               self.assertIn('content', message)
               self.assertIn('sent_at', message)
               self.assertIn('username', message)
               self.assertIn('channel_id', message)
               self.assertEqual(message['channel_id'], channel_id)
       else:
           # skip if no channels
           pass
   
   def test_channel_messages_sorted(self):
       """test that messages are time-sorted."""
       # find a real channel
       communities = get_rest_call(self, 'http://127.0.0.1:5001/communities')
       
       if communities and communities[0]['channels']:
           # use first channel
           channel_id = communities[0]['channels'][0]['id']
           messages = get_rest_call(self, f'http://127.0.0.1:5001/channels/{channel_id}/messages')
           
           # need at least 2 messages to test order
           if len(messages) >= 2:
               # get timestamps
               timestamps = [message['sent_at'] for message in messages]
               
               # check time order
               self.assertEqual(timestamps, sorted(timestamps))
   
   def test_nonexistent_channel_messages(self):
       """test getting messages from fake channel."""
       # use a channel id that doesn't exist
       channel_id_dne = 9999
       messages = get_rest_call(self, f'http://127.0.0.1:5001/channels/{channel_id_dne}/messages')
       
       # should be empty list, not error
       self.assertEqual(len(messages), 0)
   
   def test_user_suspension_info(self):
       """test user suspension data exists."""
       # get users
       users = get_rest_call(self, 'http://127.0.0.1:5001/users')
       
       # check suspension field exists
       for user in users:
           self.assertIn('suspended_until', user)