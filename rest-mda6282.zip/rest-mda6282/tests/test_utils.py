import requests

# client can only contact server using REST API calls
# for GET requests arams and header default to empty
def get_rest_call(test, url, params = {}, get_header = {}, expected_code = 200):
    response = requests.get(url, params, headers = get_header)
    test.assertEqual(expected_code, response.status_code,
        f'Response code to {url} not {expected_code}')
    return response.json()

# for POST requests, params and header default to empty
def post_rest_call(test, url, params = {}, post_header = {}, expected_code = 200):
    '''rest api using POST'''
    # add content-type header
    post_header['Content-Type'] = 'application/json'
    response = requests.post(url, json=params, headers=post_header)
    test.assertEqual(expected_code, response.status_code,
        f'Response code to {url} not {expected_code}')
    return response.json()

# for PUT requests, params and header default to empty
def put_rest_call(test, url, params = {}, put_header = {}, expected_code = 200):
    '''rest api using PUT'''
    # add content-type header
    put_header['Content-Type'] = 'application/json'
    response = requests.put(url, json=params, headers=put_header)
    test.assertEqual(expected_code, response.status_code,
        f'Response code to {url} not {expected_code}')
    return response.json()

# for DELETE requests, header defaults to empty
def delete_rest_call(test, url, delete_header={}, expected_code = 200):
    '''rest api using DELETE'''
    response = requests.delete(url, headers=delete_header)
    test.assertEqual(expected_code, response.status_code,
        f'Response code to {url} not {expected_code}')
    return response.json()